
// selecteur de page 


function changePage(page) {
    switch(page){
        case 'home' :
        window.location = "index.html/home.html";
        window.location.href = "../html/home.html";
        break;
        case 'page_1' :
            window.location = "index.html/page_1.html";
            window.location.href = "../html/page_1.html";
            break;
        case 'page_2' :
        window.location = "index.html/page_2.html";
        window.location.href = "../html/page_2.html";
        break;
    }

}

// Resolution

