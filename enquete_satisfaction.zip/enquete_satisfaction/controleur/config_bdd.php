<?php
	$serveur ="localhost";
	$bdd = "bdd_anti_gaspi";
	$user="root";
	$mdp="";

?>