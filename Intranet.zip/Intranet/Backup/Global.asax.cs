﻿using System.Web;

namespace Intranet
{
    public class Global : HttpApplication
    {
        protected void Application_Start()
        {
        }
    }
}
